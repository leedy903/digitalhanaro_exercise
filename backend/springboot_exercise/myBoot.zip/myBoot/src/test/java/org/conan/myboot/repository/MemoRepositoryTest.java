package org.conan.myboot.repository;

import jakarta.transaction.Transactional;
import lombok.extern.log4j.Log4j2;
import org.conan.myboot.domain.Memo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.Optional;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Log4j2
class MemoRepositoryTest {
    @Autowired
    MemoRepository memoRepository;

    @Test
    void textClass() {
        log.info(memoRepository.getClass().getName());
    }

    @Test
    void testInsertDummies() {
        IntStream.range(1, 100).forEach(i -> {
            Memo memo = Memo.builder().memoText("Sample..." + i).build();
            memoRepository.save(memo);
        });
    }

    @Test
    void testSelect() {
        Long mno = 10L;
        Optional<Memo> result = memoRepository.findById(mno);
        log.info("===========================");
        if(result.isPresent()) {
            Memo memo = result.get();
            log.info(memo);
        }
    }

    @Transactional
    @Test
    void testSelect2() {
        Long mno = 5L;
        Memo memo = memoRepository.getOne(mno);
        log.info("===========================");
        log.info(memo);
    }

    @Test
    void testUpdate() {
        Memo memo = Memo.builder().mno(5L).memoText("Update Text").build();
        log.info(memoRepository.save(memo));
    }

    @Test
    void testDelete() {
        Long mno = 5L;
        memoRepository.deleteById(mno);
    }

    @Test
    void testPageDefault() {
        PageRequest pageable = PageRequest.of(0, 5);
        Page<Memo> result = memoRepository.findAll(pageable);
        log.info(result);
        log.info("===================");
        log.info("Total pages: " + result.getTotalPages());
        log.info("Total count: " + result.getTotalElements());
        log.info("Page number: " + result.getNumber());
        log.info("Page size: " + result.getSize());
        log.info("Has next page?: " + result.hasNext());
        log.info("First page?: " + result.isFirst());
    }

    @Test
    void testSort() {
        Sort sort1 = Sort.by("mno").descending();
        Pageable pageable = PageRequest.of(0, 10, sort1);
        Page<Memo> result = memoRepository.findAll(pageable);
        result.get().forEach(log::info);
    }
}