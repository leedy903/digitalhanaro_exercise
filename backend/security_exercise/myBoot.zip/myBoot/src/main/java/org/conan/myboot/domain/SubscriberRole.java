package org.conan.myboot.domain;

public enum SubscriberRole {
    USER, MANAGER, ADMIN;
}
