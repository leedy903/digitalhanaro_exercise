package org.conan.myboot.domain;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class Board {
    private Integer bno;
    private String title;
    private String content;
    private String writer;
    private LocalDateTime regDate;
    private Integer hit;
}
